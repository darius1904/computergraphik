// source file #2
#include "Definition.hpp"
int b()
{
    return sum(3, 4);
}