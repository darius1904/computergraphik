// source file #1
#include "Definition.hpp"
int a()
{
    return sum(1, 2);
}